iot-dashboard
IoT: Platform for Internet of Things
Gitter License Build Status Django

You can find project details on our project page and wiki.

IOT HOOK


Fast Django server for IOT Devices
Features

Create a Django compatible server for iot devices
Create a Device for IOT Gateway Devices
Create a Sensors for IOT devices
Simple interface.
Support for channel api key
Django REST Framework
Requirements

Django
Django Rest Framework
How to get Django

Django

How to get Django Rest Framework

Django Rest Framework

Installing

git clone https://github.com/electrocoder/iotdashboard.git
Djangopackages

https://djangopackages.org/packages/p/iotdashboard/
GitHub Pages

http://electrocoder.github.io/iotdashboard/
Readthedocs

http://iotdashboard.readthedocs.io/tr/latest/
Installing Pip

https://pypi.python.org/pypi/iotdasboard
or
pip install iotdasboard
Run

./manage.py runserver
or
./manage.py runserver 0.0.0.0:8000
Test on IOTDASHBOARD

http://iotdashboard.pythonanywhere.com
Test on IHOOK

https://ihook.pythonanywhere.com
Test on HEROKU

https://iotdashboard.herokuapp.com/
Contact

Şahin MERSİN @electrocoder iothook @iothook

License

Iotdashboard source code is available under the MIT License.

Author

Şahin MERSİN @electrocoder (https://www.facebook.com/electrocoder)

Meşe Bilişim [http://mesebilisim.com/]

IoThook [http://iothook.com]